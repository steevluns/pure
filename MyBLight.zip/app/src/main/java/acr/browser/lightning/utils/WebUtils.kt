package acr.browser.lightning.utils

import acr.browser.lightning.concurrency.CoroutineDispatchers
import acr.browser.lightning.database.history.HistoryRepository
import acr.browser.lightning.di.FaviconCacheDir
import acr.browser.lightning.di.GeneratedHtmlDir
import acr.browser.lightning.di.PreviewCacheDir
import android.app.Activity
import android.app.Application
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewDatabase
import kotlinx.coroutines.withContext
import javax.inject.Inject

class WebUtils @Inject constructor(
    private val application: Application,
    private val activity: Activity,
    private val coroutineDispatchers: CoroutineDispatchers,
    private val historyRepository: HistoryRepository,
    @FaviconCacheDir private val faviconCacheDirThreadSafeFileProvider: ThreadSafeFileProvider,
    @PreviewCacheDir private val previewCacheDirThreadSafeFileProvider: ThreadSafeFileProvider,
    @GeneratedHtmlDir private val generatedHtmlDirThreadSafeFileProvider: ThreadSafeFileProvider,
) {
    suspend fun clearCookies() = withContext(coroutineDispatchers.io) {
        CookieManager.getInstance().removeAllCookies(null)
    }

    suspend fun clearWebStorage() = withContext(coroutineDispatchers.io) {
        WebStorage.getInstance().deleteAllData()
    }

    suspend fun clearHistory() = withContext(coroutineDispatchers.io) {
        historyRepository.deleteHistory()
        val webViewDatabase = WebViewDatabase.getInstance(application)
        webViewDatabase.clearHttpAuthUsernamePassword()
        faviconCacheDirThreadSafeFileProvider.file().deleteRecursively()
        previewCacheDirThreadSafeFileProvider.file().deleteRecursively()
        generatedHtmlDirThreadSafeFileProvider.file().deleteRecursively()
    }

    suspend fun clearCache() = withContext(coroutineDispatchers.io) {
        withContext(coroutineDispatchers.main) {
            val webView = WebView(activity)
            webView.clearCache(true)
            webView.destroy()
        }
        faviconCacheDirThreadSafeFileProvider.file().deleteRecursively()
        previewCacheDirThreadSafeFileProvider.file().deleteRecursively()
    }
}
